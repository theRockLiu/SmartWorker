/*
 * main.cpp
 *
 *  Created on: Jun 10, 2014
 *      Author: rock
 */

#include <iostream>


#include "test.pb.h"
using namespace std;


int main() {
	cout << "!!!Hello World!!!" << endl; // prints !!!Hello World!!!

	ns_test::regReq reg;
	reg.set_label("issssssssssssssssssssest");
	reg.set_type(1);


	unsigned char * pBuf = new unsigned char[reg.ByteSize()];
	cout << "get cached size: "<< reg.GetCachedSize()<<endl;
	reg.SerializeWithCachedSizesToArray(pBuf);
	cout << "get byte size : "<< reg.ByteSize()<<endl<< " get cache size: "<< reg.GetCachedSize()<<endl;

	ns_test::regReq reg1;
	reg1.ParseFromArray(pBuf, reg.ByteSize());

	cout << "get label: "<< reg1.label()<< " get type: "<<reg1.type() << endl;


	/*
	 * [rock@localhost test_pb]$ g++ -oexe -g3 -O0 *.cc *.cpp -lprotobuf
[rock@localhost test_pb]$ ./exe
!!!Hello World!!!
get cached size: 28
get byte size : 28
 get cache size: 28
get label: issssssssssssssssssssest get type: 1
	 *
	 *
	 *
	 * */

	return 0;
}

